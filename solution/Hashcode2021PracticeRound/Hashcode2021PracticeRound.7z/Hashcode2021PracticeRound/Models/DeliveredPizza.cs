﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hashcode2021PracticeRound.Models
{
    public class DeliveredPizza
    {
        public int TeamSize { get; set; }
        public int?[] DeliveredPizzas { get; set; }
    }
}
